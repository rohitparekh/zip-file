<?php 

	echo defined('BASEPATH') or exit('Entry is not allowed');

	/**
	 * 
	 */
	class Zipfile extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			$this->load->model('Zip','z');
		}

		function index()
		{
			$directory = 'download';
			$data['images'] = glob($directory . "/*.png");
			$this->load->view('zip',$data);
		}

		function download(){
			if($this->input->post('images')){
				$this->load->library('zip');
				$images = $this->input->post('images');
				foreach ($images as $key => $image) {
					$this->zip->read_file($image);
				}
				$this->zip->download(time() . '.zip');
			}
		}
	}