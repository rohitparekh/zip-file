<!DOCTYPE html>
<html>
<head>
	<title>Zip file</title>
	<style type="text/css">
		.block{
			height: 500px;
			width: 313px;
			padding: 20px;
			border: 1px solid #ddd;
			overflow: hidden;
			display: inline-block;
		}
		.block img{
			margin: 0 auto;
			position: relative;
			width: 300px;
			height: 469px;
		}
		.block .select{
			margin: 0 auto;
			width: 107px;
			height: 30px;
		}
		input[type='submit']{
			padding: 10px;
		}
	</style>
</head>
<body>
	<div class="container">
		<form method="post" action="<?php echo base_url('Zipfile/download') ?>">
			<?php 
				foreach ($images as $key => $value) {
					echo '
					<div class="block">
						<img src="'.base_url().'/'.$value.'" /><br />
						<input type="checkbox" name="images[]" class="select" value="'.$value.'" />
						</div>
					';
				}
			 ?>
			 <br>
			 <input type="submit" value="download" name="download" />
		</form>
	</div>
	<script type="text/javascript" src="<?php echo base_url('assets/jquery.min.js') ?>"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$('.select').click(function(){
				if(this.checked){
					$(this).parent().css('border','1px solid red');
				}else{
					$(this).parent().css('border','');
				}
			})
		})
	</script>
</body>
</html>