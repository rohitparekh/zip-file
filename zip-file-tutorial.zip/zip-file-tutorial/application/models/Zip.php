<?php 

/**
 * 
 */
class Zip extends CI_Model
{
	
	
}